<?php

	require 'database_conn.php';

	//check if the email and code exist
	if (isset($_GET['email'], $_GET['code'])) {
		if ($stmt = $conn->prepare('SELECT activation_code FROM systemuser WHERE email = ? AND is_activated = ?')) {
			$is_activated = '0';
			$stmt->bind_param('ss', $_GET['email'], $is_activated);
			$stmt->execute();
			$stmt->store_result();
			
			// check if that unactivated user email exists
			if ($stmt->num_rows > 0) {
				$stmt->bind_result($db_code);
				$stmt->fetch();
				// verify the code
				if (!password_verify($db_code, $_GET['code'])) {
					exit('Wrong activation code');
				}
				if ($stmt = $conn->prepare('UPDATE systemuser SET is_activated = ? WHERE email = ?')) {
					$new_activated = '1';
					$stmt->bind_param('ss', $new_activated, $_GET['email']);
					$stmt->execute();
					echo 'Your account is now activated! You can now <a href="login_form.php">login</a>!';
				}
			} else {
				echo 'The account is already activated or doesn\'t exist!';
			}

		}
	} else {
		echo 'email and code are not in the seesion !';
	}

	$stmt->close();

?>
