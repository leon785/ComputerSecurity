<?php
        // Server and db connection
        $db_host = "localhost";
        $db_user = "root";
        $db_password = "";
        $db_name = "SocNet";

        // // Server and db connection
        // $db_host = "localhost";
        // $db_user = "id19724952_root";
        // $db_password = "Daq2xgrastqm!";
        // $db_name = "id19724952_socnet";
        



        // try {
        //     $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_password);
        //     // set the PDO error mode to exception
        //     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //     echo "Connected successfully"; 
        // } catch(PDOException $e) {    
        //     echo "Connection failed: " . $e->getMessage();
        // }


        // Create connection
        $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
        // Check connection
        if ($conn->connect_error) {
            die ("Connection failed" .$conn->connect_error);
        }
?>