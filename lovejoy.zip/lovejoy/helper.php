<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    function send_activation_email (string $user_email, string $username, string $subject, string $body): void {
    
        require 'PHPMailer/src/Exception.php';
        require 'PHPMailer/src/PHPMailer.php';
        require 'PHPMailer/src/SMTP.php';

        $mail = new PHPMailer(true); 
        
        try {
            //Server settings
            $mail->SMTPDebug = 2;                                 // Enable verbose debug output
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'phatcat1936@gmail.com';            // SMTP username
            $mail->Password = 'rgaumptqowxxsiay';                 // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to
        
            //Recipients
            $mail->setFrom('noreply@lovejoyantiques.com', 'LoveJoy Antique');
            $mail->addAddress($user_email, $username);            // Add a recipient
        
            //Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body = $body;
        
            ob_start();
            $mail->send();
            ob_clean();

            echo 'The activation email has been sent, check your inbox or spam box.';
            
        } catch (Exception $e) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
    }


    function header_n_sendem (string $toPage, string $em): void {
        header("Location: $toPage?error=$em");
        exit();
    }


    function csrf_counter (): void {

        // CSRF Counter 
        $csrf_token = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);
        if (!$csrf_token || $csrf_token !== $_SESSION['csrf_token']) {
            // return 405 http status code
            header($_SERVER['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
            exit;
            // exit('405 Method Not Allowed');
        }
    }


    function g_captcha_check(string $toPage): void {

        if (isset($_POST['g-recaptcha-response'])) {
            $secret = "6LdpUT0jAAAAABVgT6Wj8N-sGSawpR4LWS18PwMf";
            $response = $_POST['g-recaptcha-response'];
            $remoteip = $_SERVER['REMOTE_ADDR'];
            $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip";
            $data = file_get_contents($url);
            $row = json_decode($data, true);

            if ($row['success'] == false) {
                header_n_sendem("$toPage", "Do the Human-Robot Detection");
            }
        } else {
            header_n_sendem("$toPage", "G-CAPTCHA NOT BEEN POST");
        }
    }

    function getUserIpAddr() { 

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
            $ip = $_SERVER['HTTP_CLIENT_IP']; 
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
        } else { 
            $ip = $_SERVER['REMOTE_ADDR']; 
        } 
        return $ip; 
    } 

?>