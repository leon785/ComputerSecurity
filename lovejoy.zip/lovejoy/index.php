<?php
	session_start();
	// logged in check 
	if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == False) {
		header('Location: login_form.php');
		exit;
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="index_style.css" rel="stylesheet" type="text/css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1><a href="index.php">LoveJoy Antique</a></h1>
				<a href="logout.php">Logout</a>
			</div>
		</nav>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<p><center><?php echo "Error: " . $_GET['error']; ?></center></p>
			<?php endif ?>
		</div>

		<div class="content">
			<h2>Home</h2>
			<?php
				if (isset($_SESSION['loggedin'])) {
					echo 'Welcome back, '. $_SESSION['username'] .'!';
				} else {
					echo 'User not logged in';
				}
			?>
			<br><br><br><br>
			<a href="reqEva_form.php">Request Evaluation</a>
			<br><br><br><br>
			<?php if ($_SESSION['is_admin'] === 1) { ?>
					<a href="reqList_form.php">Request List admin</a>
			<?php }?>
			
			
		</div>


	</body>
</html>