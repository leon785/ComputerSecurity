<?php
    session_start();

    require "helper.php";
    
    if (isset($_SESSION['qrcheck']) && $_SESSION['qrcheck'] == True) {
        $_SESSION['loggedin'] = True;
        unset($_SESSION['qrcode']);
        unset($_SESSION['qrcheck']);
        header('Location: index.php');
        exit();
    }

    csrf_counter();
    g_captcha_check("login_form.php");


    // entered values 
    $username = $_POST['username'];
    $password = $_POST['password'];

    // check if all data exists
    if ( !isset($username, $password) ) {
        header_n_sendem("login_form.php", "Please fill both the username and password fields");
    }
    // check if all data are not empty
    if (empty($username) || empty($password)) {
        header_n_sendem("login_form.php", "Please complete the registration form");
    }



    // ====================================================================
    require 'database_conn.php';
    require __DIR__ . '/vendor/autoload.php';

    $ip_address = getUserIpAddr();


    // PRE-CHECK LOGIN ATTEMPT
    if ($stmt = $conn->prepare('SELECT id, attempt, banned_time FROM login_attempt WHERE username = ? AND ip_address = ?')) {
        $stmt->bind_param('ss', $username, $ip_address);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id_rec, $attempt_rec, $banned_time_rec);
            $stmt->fetch();

            $remain_time = time()-$banned_time_rec;
            // STILL SHOULD BE BANNED
            if ($attempt_rec >= 5 && $remain_time < 86400) {
                header_n_sendem("login_form.php", "You are banned in 24h as too many attempts");
            } 
            // CAN BE UNBANNED NOW
            if ($attempt_rec >= 5 && $remain_time > 86400) {
                if ($stmt = $conn->prepare('UPDATE login_attempt SET attempt = ? WHERE id = ?')) {
                    $attempt_rec = 0;
                    $stmt->bind_param('ii', $attempt_rec, $id_rec);
                    $stmt->execute();
                } 
            }
        } 
    } else {
        header_n_sendem("login_form.php", "Cannot prepare stmt of PRE-CHECK LOGIN ATMPT");
    }

    // SELECT the user info in the database
    if ($stmt = $conn->prepare('SELECT id, email, first_ip FROM systemuser WHERE username = ?')) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {

            $stmt->bind_result($id_db, $email_db, $first_ip_db);
            $stmt->fetch();

            // check if ips are different
            if ($ip_address != $first_ip_db) {
                // Alert the user by email
                $subject = "DIFFERENT IP ALERT";
                $body = "Your account of LoveJoy Antique are logging-in in another ip address.";
                send_activation_email($email_db, $username, $subject, $body);
            }

            // check if the user has activated the account
            if ($stmt = $conn->prepare('SELECT id, passwd, is_admin, tfa_seckey FROM systemuser WHERE username = ? AND is_activated = ?')) {
                $is_activated = '1';
                $stmt->bind_param('ss', $username, $is_activated);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {

                    // NOW GO TO VERIFY THE PASSWORD BELOW
                    $stmt->bind_result($id_db, $password_db, $is_admin, $secret_key);
                    $stmt->fetch();

                } else {
                    // NOT ACTIVATED yet, go to activate the account
                    $uniqid = uniqid();
                    if ($stmt = $conn->prepare('UPDATE systemuser SET activation_code = ? WHERE id = ?')) {
                        $stmt->bind_param('ss', $uniqid, $id_db);
                        $stmt->execute();

                        $uniqid_hashed = password_hash($uniqid, PASSWORD_DEFAULT);
                        $_SESSION['email'] = $email_db;
                        $_SESSION['username'] = $username;
                        $_SESSION['subject'] = 'Account Activation Required';
                        // $activate_link = 'http://web594319279.000webhostapp.com/activate.php?email=' . $email_db . '&code=' . $uniqid_hashed;
                        $activate_link = 'http://localhost/lovejoy/activate.php?email=' . $email_db . '&code=' . $uniqid_hashed;
                        // $_SESSION['body'] = '<p>Please click the following link to activate your account: <br><br>' . $activate_link . '</p>';
                        $_SESSION['body'] = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a></p>';

                        exit("<b>DO NOT LEAVE THIS PAGE UNTIL YOU FINISHED ACTIVATION! </b><br><br>
                        Your email has not been activated, <a href='login_email_activate_do.php'>send an email</a> for activation and then login."
                        );                  
                    } else {
                        header_n_sendem("login_form.php", "Cannot prepare stmt of UPDATE activation_code !");
                    }
                }
            } else {
                header_n_sendem("login_form.php", "Cannot prepare stmt of SELECT activated user !");
            }

        } else {
            header_n_sendem("login_form.php", "Cannot find this user in the database");
        }
    } else {
        header_n_sendem("login_form.php", "Cannot prepare stmt of SELECT user !");
    }
    

    // PASSWORD VERIFY
    if (password_verify($password, $password_db)) {

        // SET BACK BAN RESTRICTS IF HAS
        if ($stmt = $conn->prepare('SELECT id FROM login_attempt WHERE username = ? AND ip_address = ?')) {
            $stmt->bind_param('ss', $username, $ip_address);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id_rec);
                $stmt->fetch();

                if ($stmt = $conn->prepare('UPDATE login_attempt SET attempt = ? AND banned_time = ? WHERE id = ?')) {
                    $attempt_rec = 0;
                    $banned_time_rec = 0;
                    $stmt->bind_param('iii', $attempt_rec, $banned_time_rec, $id_rec);
                    $stmt->execute();
                } else {
                    header_n_sendem("login_form.php", "Cannot prepare stmt of UPDATE login_attempt AFTER LOGIN");
                }

            }
        } 

        session_regenerate_id();
        $_SESSION['id'] = $id_db;
        $_SESSION['username'] = $username;
        $_SESSION['is_admin'] = $is_admin;

        // LAST LOGIN TIME CHECK
        if ($stmt = $conn->prepare('SELECT last_login FROM systemuser WHERE id = ? AND username = ?')) {
            $stmt->bind_param('ss', $id_db, $username);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {

                $stmt->bind_result($last_login);
                $stmt->fetch();
                $time_now = time();
                if ($time_now - $last_login < 1800) {
                    $_SESSION['loggedin'] = True;
                    header('Location: index.php');
                    exit();
                }

                // QR code generaion
                $google2fa = new \PragmaRX\Google2FA\Google2FA();
                // $text = $google2fa->getQRCodeUrl('LoveJoy Antique', $username, $secret_key);
                $text = $google2fa->getQRCodeUrl('localhost', $username, $secret_key);
                $image_url = 'https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl='.$text;
                $_SESSION['qrcode'] = '<img src="'.$image_url.'" />';
                header('Location: qr_form.php');
                exit();

            } else {
                header_n_sendem("login_form.php", "Unknown error in the login time check");
            }
        } else {
            header_n_sendem("login_form.php", "Cannot prepare stmt of SELECT last_login");
        }

    // PASSWORD WRONG
    } else {

        if ($stmt = $conn->prepare('SELECT id, attempt, banned_time FROM login_attempt WHERE username = ? AND ip_address = ?')) {
            $stmt->bind_param('ss', $username, $ip_address);
            $stmt->execute();
            $stmt->store_result();

            // NO SUCH AN IP ADDRESS
            if ($stmt->num_rows < 1) {
                // store in a new row
                if ($stmt = $conn->prepare('INSERT INTO login_attempt (username, ip_address) VALUES (?, ?)')) {
                    $stmt->bind_param('ss', $username, $ip_address);
                    $stmt->execute();
                } else {
                    header_n_sendem("login_form.php", "Cannot prepare stmt of INSERT login_attempt");
                }
                if ($stmt = $conn->prepare('SELECT id, attempt, banned_time FROM login_attempt WHERE username = ? AND ip_address = ?')) {
                    $stmt->bind_param('ss', $username, $ip_address);
                    $stmt->execute();
                    $stmt->store_result();
                    $stmt->bind_result($id_la, $attempt, $banned_time);
                    $stmt->fetch();
                } else {
                    header_n_sendem("login_form.php", "Cannot prepare stmt2 of SELECT login_attempt");
                }
            // HAVE THIS IP ADDRESS 
            } else {
                $stmt->bind_result($id_la, $attempt, $banned_time);
                $stmt->fetch();
            }

            // ADDING ATTEMPT RECORD
            if ($stmt = $conn->prepare('UPDATE login_attempt SET attempt = ? WHERE id = ?')) {
                $attempt = $attempt + 1;
                $stmt->bind_param('is', $attempt, $id_la);
                $stmt->execute();
            } else {
                header_n_sendem("login_form.php", "Cannot prepare stmt of UPDATE attempt");
            }
            // CHECK IF IT'S UP-LIMIT ATTEMPT TIME
            if ($attempt >= 5) {
                if ($stmt = $conn->prepare('UPDATE login_attempt SET banned_time = ? WHERE id = ?')) {
                    $new_banned_time = time();
                    $stmt->bind_param('is', $new_banned_time, $id_la);
                    $stmt->execute();
                } else {
                    header_n_sendem("login_form.php", "Cannot prepare stmt of UPDATE banned_time");
                }
            }

        } else {
            header_n_sendem("login_form.php", "Cannot prepare stmt1 of SELECT login_attempt");
        }

        header_n_sendem("login_form.php", "Incorrect username and/or password");

    }

    $stmt->close();
    $conn->close();
?>
