<?php
    session_start();

    require "helper.php";

    csrf_counter();


    // if (isset($_POST['submit'])) {
    //     print_r($_POST); die();
    // }


    // entered values 
    $username = $_POST['username'];
    $password = $_POST['password'];

    // check if all data exists
    if ( !isset($username, $password) ) {
        header_n_sendem("login_form.php", "Please fill both the username and password fields");
    }
    // check if all data are not empty
    if (empty($username) || empty($password)) {
        header_n_sendem("login_form.php", "Please complete the registration form");
    }


    
    // ====================================================================
    require 'database_conn.php';


    // check if the user is in the database
    if ($stmt = $conn->prepare('SELECT id, email FROM systemuser WHERE username = ?')) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {

            $stmt->bind_result($id_db, $email_db);
            $stmt->fetch();

            // check if the user has activated the account
            if ($stmt = $conn->prepare('SELECT id, passwd, is_admin FROM systemuser WHERE username = ? AND is_activated = ?')) {
                $is_activated = '1';
                $stmt->bind_param('ss', $username, $is_activated);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {

                    // bind results and check if the password is correct
                    $stmt->bind_result($id_db, $password_db, $is_admin);
                    $stmt->fetch();
                    if (!password_verify($password, $password_db)) {
                        header_n_sendem("login_form.php", "Incorrect username and/or password");
                    }

                } else {

                    // not activated yet, go to activate the account
                    $uniqid = uniqid();
                    if ($stmt = $conn->prepare('UPDATE systemuser SET activation_code = ? WHERE id = ?')) {
                        $stmt->bind_param('ss', $uniqid, $id_db);
                        $stmt->execute();

                        $_SESSION['email'] = $email_db;
                        $_SESSION['username'] = $username;
                        $_SESSION['subject'] = 'Account Activation Required';
                        // $activate_link = 'http://web594319279.000webhostapp.com/activate.php?email=' . $email_db . '&code=' . $uniqid;
                        $activate_link = 'http://localhost/lovejoy/activate.php?email=' . $email_db . '&code=' . $uniqid;
                        $_SESSION['body'] = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a></p>';

                        header_n_sendem(
                            "login_form.php", 
                            "Your email has not been activated, <a href='login_email_activate_do.php'>send an email</a> for activation and then <a href='login_form.php'> login </a>."
                        );

                                                
                    } else {
                        header_n_sendem("login_form.php", "Cannot prepare stmt of UPDATE activation_code !");
                    }

                }
            } else {
                header_n_sendem("login_form.php", "Cannot prepare stmt of SELECT activated user !");
            }

        } else {
            header_n_sendem("login_form.php", "Cannot find this user in the database");
        }
    } else {
        header_n_sendem("login_form.php", "Cannot prepare stmt of SELECT user !");
    }


    // 2fa pin-email check
    session_regenerate_id();
    $_SESSION['username'] = $username;
    $_SESSION['id'] = $id_db;
    $_SESSION['is_admin'] = $is_admin;

    // send pin email
    

    $stmt->close();
    $conn->close();
?>
