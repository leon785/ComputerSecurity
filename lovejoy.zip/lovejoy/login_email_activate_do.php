<?php

	session_start();
	require_once __DIR__ . '/helper.php';

	send_activation_email($_SESSION['email'], $_SESSION['username'], $_SESSION['subject'], $_SESSION['body']);

	unset($_SESSION['email']);
	unset($_SESSION['subject']);
	unset($_SESSION['body']);
	
?>