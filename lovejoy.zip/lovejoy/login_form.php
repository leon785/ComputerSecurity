<?php
    session_start();
    session_unset();
	$_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true));

	// error_reporting(-1);

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="login_style.css" type="text/css">
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	</head>
	

	<body>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>

		<div class="login">
			<h1>Login</h1>
			<form action="login_check.php" method="POST">
				<label for="username">Username:</label>
				<input type="text" name="username" placeholder="Enter 2 to 8 charactors" id="username" value="leon" required>
				<label for="password">Password:</label>
				<input type="password" name="password" placeholder="Enter 8 to 16 charactors" id="password" value="Daq2xgrastqm!" required>
				<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
				<div class="g-recaptcha" data-sitekey="6LdpUT0jAAAAAOD1we4aOZnBRfSLCrtHWGR1Mpbt"></div>
				<input type="submit" name="next" value="Next" id="next">
			</form>
		</div>

        <div class="toDo">
            <?php
                echo "Click to <a href='register_form.php'>Register</a>";
				echo "  |  ";
                echo "Forgot <a href='resetPwd_form.php'>PASSWORD</a> ? ";
            ?>
        </div>

	</body>
</html>



