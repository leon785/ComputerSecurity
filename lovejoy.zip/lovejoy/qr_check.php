<?php
    session_start();

    require "helper.php";

    csrf_counter();
    

    // check if data exists
    if ( !isset($_POST['authnum']) ) {
        header_n_sendem("qr_form.php", "Please complete the box");
    }
    // check if data is not empty
    if (empty($_POST['authnum'])) {
        header_n_sendem("qr_form.php", "Please complete the box");
    }

    // check authnum is valid
    $authnum = $_POST['authnum'];
    if (preg_match('/^[\d]{6}$/', $authnum) == 0) {
        header_n_sendem("qr_form.php", "Incorrect pin form");
    }

    require 'database_conn.php';

    if (isset($_SESSION['username'])) {
        if ($stmt = $conn->prepare('SELECT id, tfa_seckey FROM systemuser WHERE username = ?')) {
            $stmt->bind_param('s', $_SESSION['username']);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $secret_key);
                $stmt->fetch();

                require __DIR__ . '/vendor/autoload.php';
                $google2fa = new \PragmaRX\Google2FA\Google2FA();

                // Key Verification
                if ($google2fa->verifyKey($secret_key, $authnum)) {

                    // THEN STORE THE TIMESTAMP NOW
                    if ($stmt = $conn->prepare('UPDATE systemuser SET last_login = ? WHERE id = ?')) {
                        $time_now = time();
                        $stmt->bind_param('is', $time_now, $id);
                        $stmt->execute();
                    } else {
                        header_n_sendem("qr_form.php", "Cannot prepare stmt of UPDATE last_login");
                    }

                    $_SESSION['qrcheck'] = True;
                    header('Location: login_check.php');
                    exit();
                } else {
                    header_n_sendem("qr_form.php", "Incorrect pin");
                }

            } else {
                header_n_sendem("qr_form.php", "User not found");
            }
        } else {
            header_n_sendem("qr_form.php", "Cannot prepare to SELECT the seckey");
        }
    } else {
        exit('Please enter your username before verify by QR code');
    }


?>