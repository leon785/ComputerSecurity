<?php 
    session_start(); 

    if (!isset($_SESSION['qrcode'])) {
        exit("No QR code is generated");
    }

    $_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true));

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="qr_style.css" type="text/css">
	</head>
	

	<body>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>

        <div class=qrcode>
            <h1>Scan the QR code</h1>
            <form action="qr_check.php" method="POST">
                (Use "<b>Google Authenticator</b>" app to scan below)<br><br>
                <?php echo $_SESSION['qrcode']; ?>
                <label for="authnum">Enter your 6-digit pin:</label>
                <input type="number" name="authnum" maxlength="6" placeholder="only do this once in 30 min" id="authnum" required>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="submit" name="submit" value="Submit" id="submit">
            </form>
        </div>

		<div class="toLog">
            <?php
                echo "Back to <a href='login_form.php'> LOGIN </a>";
            ?>
        </div>

	</body>
</html>


