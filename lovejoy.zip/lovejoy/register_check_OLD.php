<?php
    session_start();

    require 'helper.php';

    csrf_counter();

    
    // check if all data exists
    if (!isset($_POST['username'], $_POST['password1'], $_POST['password2'], $_POST['fname'], $_POST['sname'], $_POST['phone'], $_POST['email'])) {
        header_n_sendem("register_form.php", "Please complete the registration form");
    }
    // check if all data are not empty
    if (empty($_POST['username']) || empty($_POST['password1']) || empty($_POST['password2']) || empty($_POST['fname']) || empty($_POST['sname']) || empty($_POST['phone']) || empty($_POST['email'])) {
        header_n_sendem("register_form.php", "Please complete the registration form");
    }


    // username
    $username = htmlspecialchars($_POST['username']);
    if ($username != $_POST['username']) {
        header_n_sendem("register_form.php", "Username contains invalid symbol");
    }
    if (preg_match('/^[\w_]{2,8}$/', $username) == 0) {
        header_n_sendem("register_form.php", "Username is in wrong pattern");
    }
    
    // password
    $password1 = htmlspecialchars($_POST['password1']);
    $password2 = htmlspecialchars($_POST['password2']);
    if (($password1 != $_POST['password1']) || ($password2 != $_POST['password2'])) {
        header_n_sendem("register_form.php", "Password contain invalid symbol");
    }
    if ($password1 != $password2) {
        header_n_sendem("register_form.php", "Two passwords are different");
    }
    
    if ((strlen($password1) < 8) || strlen($password1) > 16 ||
        !preg_match('@[A-Z]@', $password1) || !preg_match('@[a-z]@', $password1) ||
        !preg_match('@[0-9]@', $password1) || !preg_match('@[_?!]@', $password1)) {
        header_n_sendem("register_form.php", "password in wrong pattern or is not strong enough");
    }

    // forename & surname
    $forename = htmlspecialchars($_POST['fname']);
    $surname = htmlspecialchars($_POST['sname']);
    if ($forename != $_POST['fname']) {
        header_n_sendem("register_form.php", "Forename contains invalid symbol");
    } 
    if ($surname != $_POST['sname']) {
        header_n_sendem("register_form.php", "Surname contains invalid symbol");
    }

    // phone
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
    if (filter_var($phone, FILTER_VALIDATE_INT) === false) {
        header_n_sendem("register_form.php", "Invalid phone number");
    }
    
    // email
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        header_n_sendem("register_form.php", "Invalid email address");
    }

    // security Q&A
    $sec_ques = $_POST['sec_ques'];
    $sec_ans = htmlspecialchars($_POST['sec_ans']);
    if ($sec_ans != $_POST['sec_ans']) {
        header_n_sendem("register_form.php", "Security answer contains invalid symbol");
    }


    
    // ====================================================================
    require 'database_conn.php';
    


    // get stmt1 if that username exists.
    if ($stmt1 = $conn->prepare('SELECT id, passwd FROM systemuser WHERE username = ?')) {
        $stmt1->bind_param('s', $username);
        $stmt1->execute();
        $stmt1->store_result();
    } else {
        header_n_sendem("register_form.php", "Cannot prepare statement 1 !");
    }

    // get stmt2 if that email exists.
    if ($stmt2 = $conn->prepare('SELECT id, passwd FROM systemuser WHERE username = ? AND email = ?')) {
        $stmt2->bind_param('ss', $username, $email);
        $stmt2->execute();
        $stmt2->store_result();
    } else {
        header_n_sendem("register_form.php", "Cannot prepare statement 2 !");
    }

    // check and insert a new row
    if ($stmt1->num_rows > 0) {
        header_n_sendem("register_form.php", "Username exists, please choose another one");
    } 
    elseif ($stmt2->num_rows > 0) {
        header_n_sendem("register_form.php", "Email has already been used, please choose another one");
    } else {

        // Username and Email both dont exist, now can insert new systemuser
        if ($stmt1 = $conn->prepare('INSERT INTO systemuser (username, passwd, forename, surname, phone, email, activation_code, sec_ques, sec_ans) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')) {
            
            // deal with the rest of params
            $password = password_hash($password1, PASSWORD_DEFAULT);
            $uniqid = uniqid();
            $sec_ans = password_hash($sec_ans, PASSWORD_DEFAULT);

            // pass the params and execute
            $stmt1->bind_param('sssssssss', $username, $password, $forename, $surname, $phone, $email, $uniqid, $sec_ques, $sec_ans);
            $stmt1->execute();

            // sending authentication email
            $uniqid_hashed = password_hash($uniqid, PASSWORD_DEFAULT);
            $subject =  'Account Activation Required';
            // $activate_link = 'http://web594319279.000webhostapp.com/activate.php?email=' . $email_db . '&code=' . $uniqid_hashed;
            $activate_link = 'http://localhost/lovejoy/activate.php?email=' . $email . '&code=' . $uniqid_hashed;
            $body = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a></p>';
            send_activation_email($email, $username, $subject, $body);

        } else {
            header_n_sendem("register_form.php", "Cannot prepare stmt of INSERT info !");
        }
    }
    
    $stmt1->close();
    $stmt2->close();
    $conn->close();
?>
