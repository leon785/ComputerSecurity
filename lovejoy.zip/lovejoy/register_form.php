<?php
    session_start();
    session_unset();
	$_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true));
?>


<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="register_style.css" type="text/css">
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	</head>
	
	<body>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>

		<div class="register">
			<h1>Sign Up</h1>
			<form action="register_check.php" method="POST">
                <label for="username">Username:</label>
				<input type="text" name="username" placeholder="need 2 to 8 charactors, special symbol could be: _" maxlength="8" pattern="^[\w_]{2,8}$" id="username" required>
                <label for="password1">Password:</label>
				<input type="password" name="password1" placeholder="need 8 to 16 charactors, special symbol could be: _ ? !" pattern="^[\w_?!]{8,16}$" id="password1" required>
				<label for="password1"><font color=blue>Password needs to have at least 1 Uppercase letter 1 Lowercase letter 1 digit number 
             1 special chars and should be 8-16 chars in total</font></label><br><br><br><br>
                <label for="password2">Type in the password again:</label>
				<input type="password" name="password2" placeholder="need 8 to 16 charactors, special symbol could be: _ ? !" pattern="^[\w_?!]{8,16}$" id="password2" required>
                <label for="fname">Forename:</label>
				<input type="text" name="fname" placeholder="forename" maxlength="20" id="fname" required>
                <label for="sname">Surname:</label>
				<input type="text" name="sname" placeholder="surname" maxlength="20" id="sname" required>
                <label for="phone">Phone Number:</label>
                <input type="tel" name="phone" placeholder="phone number" id="phone" required>
                <label for="email">Email Address:</label>
				<input type="email" name="email" placeholder="email address" id="email" required>
				<label for="sec_ques">Security Question:</label>
				<select name="sec_ques" value="What city were you born in ?" id="sec_ques">
					<option>What city were you born in ?</option>
					<option>What food is your favourite ?</option>
					<option>What movie do you like most ?</option>
				</select><br><br>
				<label for="sec_ans">Enter you answer here (case-sensitive):</label>
				<input type="text" name="sec_ans" id="sec_ans" maxlength="20" required>
				<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
				<div class="g-recaptcha" data-sitekey="6LdpUT0jAAAAAOD1we4aOZnBRfSLCrtHWGR1Mpbt"></div>
				<input type="submit" value="Go to email verification" id="submit">
			</form>
		</div>

		<input type="hidden" name="token_generate" id="token_generate">

		<div class="toLog">
            <?php
                echo "Have an account already? Back to <a href='login_form.php'> LOGIN </a>";
            ?>
        </div>

	</body>
</html>


























