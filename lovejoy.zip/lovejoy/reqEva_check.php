<?php
    session_start();

    require 'helper.php';

    csrf_counter();
    g_captcha_check("reqEva_form.php");

    // check if all data exists
    if ( !isset($_FILES['image']) || !isset($_POST['contact']) || !isset($_POST['detail']) ) {
        header_n_sendem("reqEva_form.php", "Please complete the request");
    }
    // check if all data are not empty
    if (empty($_FILES['image']) || empty($_POST['contact']) ||empty($_POST['detail'])) {
        header_n_sendem("reqEva_form.php", "Please complete the request");
    }


    // contact
    $img_contact = $_POST['contact'];

    // detail
    $img_detail = htmlspecialchars($_POST['detail']);;
    if ($img_detail != $_POST['detail']) {
        header_n_sendem("reqEva_form.php", "Detail contains invalid symbol");
    }


    // image
    $img_name = $_FILES['image']['name'];
    $img_size = $_FILES['image']['size'];
    $tmp_name = $_FILES['image']['tmp_name'];
    $error = $_FILES['image']['error'];

    if ($error === 0) {

        // no more than 1mb
        if ($img_size > 1048576) {
            header_n_sendem("reqEva_form.php", "The image is too large, should be no more than 1mb");
        } else {

            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);
            $allowed_type = array("jpg", "jpeg", "png");

            // save it
            if (in_array($img_ex_lc, $allowed_type)) {
                $new_img_name = uniqid("IMG-", true). "." .$img_ex_lc;
                $img_upload_path = 'img_upload/' .$new_img_name;
                move_uploaded_file($tmp_name, $img_upload_path);
            } else {
                header_n_sendem("reqEva_form.php", "The file is in the wrong type");
            }
        }

    } else {
        header_n_sendem("reqEva_form.php", "Unknown error");
    }



    // ====================================================================

    $user_name = $_SESSION['username'];
    $user_id = $_SESSION['id'];

    require 'database_conn.php';
    
    if ($stmt = $conn->prepare("INSERT INTO request (image_url, contact, detail, uploader) VALUES (?, ?, ?, ?)")) {
        $stmt->bind_param('ssss', $img_upload_path, $img_contact, $img_detail, $user_name);
        $stmt->execute();
        exit("Send the request successfully, please wait for the reply.<a href=reqEva_form.php> Go back </a>.");

    } else {
        header_n_sendem("reqEva_form.php", "Cannot prepare stmt of INSERT image !");
    }

    $stmt->close();
    $conn->close();
?>


