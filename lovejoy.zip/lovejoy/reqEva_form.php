<?php
	session_start();

	// logged in check 
	if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == False) {
		header('Location: login_form.php');
		exit;
	}

	$_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true));
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="reqEva_style.css" rel="stylesheet" type="text/css">
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	</head>


	<body>

		<nav class="navtop">
			<div>
				<h1><a href="index.php">LoveJoy Antique</a></h1>
				<a href="logout.php">Logout</a>
			</div>
		</nav>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>

		<div class="content">
			<h2>Request Evaluation</h2>
            <h3>Upload your request here</h3>
            <br><br>
            <form action="reqEva_check.php" enctype="multipart/form-data" method="POST">
				Image:
                <input type="file" accept="image/*" name="image" required>
                Contact by:
                <select name="contact" value="email">
                    <option> email </option>
                    <option> phone </option>
                </select>
                <br/><br/>
                <input type="text" name="detail" placeholder="Type in the details of the object" id="detail" size="255" maxlength="255" required>
                <br>
				<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
				<div class="g-recaptcha" data-sitekey="6LdpUT0jAAAAAOD1we4aOZnBRfSLCrtHWGR1Mpbt"></div>
                <input type="submit" value="Submit">
            </form>    
		</div>

	</body>
</html>