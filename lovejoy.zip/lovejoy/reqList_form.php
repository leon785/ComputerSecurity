<?php
    session_start();

    require 'helper.php';

    // logged in check 
	if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == False) {
		header('Location: login_form.php');
		exit();
	} elseif ($_SESSION['is_admin'] != 1) {
        header_n_sendem("index.php", "You are not administrator");
    }
?>

<!DOCTYPE html>
<html>
	<head>
        <title>Request List</title>
		<meta charset="utf-8">
		<link href="reqList_style.css" rel="stylesheet" type="text/css">
	</head>
	<body class="loggedin">
		<nav class="navtop">

			<div>
				<h1><a href="index.php">LoveJoy Antique</a></h1>
				<a href="logout.php">Logout</a>
			</div>
		</nav>

        <div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>

		<div class="content">
			<h2>Request List (ADMIN)</h2>

            <?php
                require 'database_conn.php';

                $sql = "SELECT * FROM request ORDER BY id DESC";
                $res = mysqli_query($conn, $sql);

                if (mysqli_num_rows($res) > 0) {
                    while ($images = mysqli_fetch_assoc($res)) {
            ?>
                        <div class="request">
                            <img src="<?=$images['image_url']?>" width=300 height=200>
                            <br>
                            <?php echo "id: " . $images['id']; ?>
                            <br>
                            <?php echo "detail: " . $images['detail']; ?>
                            <br>
                            <?php echo "contact: " . $images['contact']; ?>
                        </div>
            <?php
                    }
                }
            ?>
			
		</div>

	</body>
</html>