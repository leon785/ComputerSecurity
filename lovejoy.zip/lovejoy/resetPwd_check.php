<?php
    session_start();

    require 'helper.php';


    if (!isset($_SESSION['resetstep'])) {

        csrf_counter();

        // check if all data exists
        if (!isset($_POST['username'], $_POST['email'])) {
            header_n_sendem("resetPwd_form.php", "Please complete the boxes");
        }
        // check if all data are not empty
        if (empty($_POST['username']) || empty($_POST['email'])) {
            header_n_sendem("resetPwd_form.php", "Please complete the boxes");
        }
        // username
        $username = htmlspecialchars($_POST['username']);
        if ($username != $_POST['username']) {
            header_n_sendem("resetPwd_form.php", "Username contains invalid symbol");
        }
        // email
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            header_n_sendem("resetPwd_form.php", "Invalid email address");
        }
        
        require 'database_conn.php';

        // check if that username exists.
        if ($stmt = $conn->prepare('SELECT id, sec_ques, sec_ans FROM systemuser WHERE username = ? AND email = ?')) {
            $stmt->bind_param('ss', $username, $email);
            $stmt->execute();
            $stmt->store_result();
            // find the user
            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $sec_ques, $sec_ans);
                $stmt->fetch();
                $_SESSION['id'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['resetstep'] = "step1";
                $_SESSION['sec_ques_db'] = $sec_ques;
                $_SESSION['sec_ans_db'] = $sec_ans;
                header('Location: resetPwd_form.php');
                exit();
            } else {
                header_n_sendem("resetPwd_form.php", "No such a user/email in the database");
            }
        } else {
            header_n_sendem("resetPwd_form.php", "Cannot prepare stmt of SELECT user for reseting !");
        }


    } else {


        if ($_SESSION['resetstep'] === "step1") {
            // check if data exists
            if (!isset($_POST['sec_ans'])) {
                header_n_sendem("resetPwd_form.php", "Please complete the box");
            }
            // check if data is not empty
            if (empty($_POST['sec_ans'])) {
                header_n_sendem("resetPwd_form.php", "Please complete the box");
            }
            // check form of security answer
            $sec_ans = htmlspecialchars($_POST['sec_ans']);
            if ($sec_ans != $_POST['sec_ans']) {
                header_n_sendem("resetPwd_form.php", "Security answer contains invalid symbol");
            }

            // check if the answer is correct
            if (password_verify($sec_ans, $_SESSION['sec_ans_db'])) {
                $_SESSION['resetstep'] = "step2";
                unset($_SESSION['sec_ques_db']);
                unset($_SESSION['sec_ans_db']);
                header('Location: resetPwd_form.php');
                exit();
            } else {
                header_n_sendem("resetPwd_form.php", "Incorrect answer");
            }
        } 
        
        elseif ($_SESSION['resetstep'] === "step2") {

            g_captcha_check("resetPwd_form.php");

            // check if data exists
            if (!isset($_POST['new_pwd1'], $_POST['new_pwd2'])) {
                header_n_sendem("resetPwd_form.php", "Please complete the boxes");
            }
            // check if data is not empty
            if (empty($_POST['new_pwd1']) || empty($_POST['new_pwd2'])) {
                header_n_sendem("resetPwd_form.php", "Please complete the boxes");
            }
            $new_pwd1 = htmlspecialchars($_POST['new_pwd1']);
            $new_pwd2 = htmlspecialchars($_POST['new_pwd2']);
            if (($new_pwd1 != $_POST['new_pwd1']) || ($new_pwd2 != $_POST['new_pwd2'])) {
                header_n_sendem("resetPwd_form.php", "Password contain invalid symbol");
            }
            if ($new_pwd1 != $new_pwd2) {
                header_n_sendem("resetPwd_form.php", "Two passwords are different");
            }
            // PASSWORD PATTERN
            if ((strlen($new_pwd1) < 8) || strlen($new_pwd1) > 16 ||
                !preg_match('@[A-Z]@', $new_pwd1) || !preg_match('@[a-z]@', $new_pwd1) ||
                !preg_match('@[0-9]@', $new_pwd1) || !preg_match('@[_?!]@', $new_pwd1)) {
                header_n_sendem("resetPwd_form.php", "password in wrong pattern or is not strong enough");
            }
            // PREVENT DICTIONARY ATTACK
            $handle = fopen('./common_password/com_pwds.txt', 'r'); 
            if ($handle) {
                while (false !== ($com_pwd = fgets($handle,256))) {
                    if ($new_pwd1 == $com_pwd)  {
                        header_n_sendem("resetPwd_form.php", "Password is vulnerable to Dictionary Attacks");
                    }
                }
            } else {
                header_n_sendem("resetPwd_form.php", "Failed to open the pwd TXT");
            }
            fclose($handle);

            require 'database_conn.php';

            // first check if pwd new == old
            if ($stmt = $conn->prepare('SELECT passwd FROM systemuser where id = ? AND username = ?')) {
                $stmt->bind_param('ss', $_SESSION['id'], $_SESSION['username']);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    $stmt->bind_result($old_pwd);
                    $stmt->fetch();
                    // Cannot be the same as the old one
                    if (password_verify($new_pwd1, $old_pwd)) {
                        header_n_sendem("resetPwd_form.php", "Your new password is the same as the old one");
                    }
                } else {
                    header_n_sendem("resetPwd_form.php", "session error: cannot find the user in database");
                }
            } else {
                header_n_sendem("resetPwd_form.php", "Cannot prepare stmt of SELECT pwd");
            }

            // now we can update new pwd into db
            if ($stmt = $conn->prepare('UPDATE systemuser SET passwd = ? WHERE id = ?')) {
                $hashed_pwd = password_hash($new_pwd1, PASSWORD_DEFAULT);
                $stmt->bind_param('ss', $hashed_pwd, $_SESSION['id']);
                $stmt->execute();
                exit('Your password has now been reset! Go to <a href="login_form.php">login</a>.');
            } else {
                header_n_sendem("resetPwd_form.php", "Cannot prepare stmt of UPDATE pwd");
            }
        } 
        
        else {
            exit('Unknown session value found when reseting password');
        }
    }


?>