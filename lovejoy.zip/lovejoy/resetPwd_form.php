<?php session_start(); ?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="resetPwd_style.css" type="text/css">
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	</head>
	

	<body>

		<div class="em">
			<?php if(isset($_GET['error'])): ?>
				<script>alert(" Error: <?php echo $_GET['error']; ?> ");</script>
			<?php endif ?>
		</div>



        <!-- reset steps -->
        <?php if (!isset($_SESSION['resetstep'])) { ?>

            <?php $_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true)); ?>

            <!-- initial input -->
            <div class=reset>
                <h1>Reset your password</h1>
                <form action="resetPwd_check.php" method="POST">
                    <center><b>Step 0</b></center>
                    <label for="username">Username:</label>
                    <input type="text" name="username" placeholder="Enter 2 to 8 charactors" id="username" required>
                    <label for="email">Email Address:</label>
                    <input type="email" name="email" placeholder="your email address" id="email" required>
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="submit" value="Go to answer Security Question" id="submit">
                </form>
            </div>

        <?php } else {?>
            <?php if ($_SESSION['resetstep'] === "step1") { ?>

                <!-- step 1 -->
                <div class=reset>
                    <h1>Reset your password</h1>
                    <form action="resetPwd_check.php" method="POST">
                        <center><b>Step 1</b></center>
                        <label for="sec_ques">Security Question:</label>
                        <font color=red><b><?php echo $_SESSION['sec_ques_db']; ?></b></font>
                        <label for="sec_ans">Enter you answer here (case-sensitive):</label>
                        <input type="text" name="sec_ans" id="sec_ans" maxlength="20" required>
                        <input type="submit" value="Go to set new password" id="submit">
                    </form>
                </div>

            <?php } elseif ($_SESSION['resetstep'] === "step2") { ?>

                <!-- step 2 -->
                <div class=reset>
                    <h1>Reset your password</h1>
                    <form action="resetPwd_check.php" method="POST">
                        <center><b>Step 2</b></center>
                        <label for="new_pwd1">Set your new password:</label>
                        <input type="password" name="new_pwd1" id="new_pwd1" required>
                        <label for="new_pwd2">Enter your new password again:</label>
                        <input type="password" name="new_pwd2" id="new_pwd2" required>
                        <div class="g-recaptcha" data-sitekey="6LdpUT0jAAAAAOD1we4aOZnBRfSLCrtHWGR1Mpbt"></div>
                        <input type="submit" value="Submit" id="submit">
                    </form>
                </div>

            <?php } else { ?>
                <b>Unknown session value found when reseting password</b>
            <?php } ?>

        <?php } ?>



		<div class="toLog">
            <?php
                echo "Back to <a href='login_form.php'> LOGIN </a>";
            ?>
        </div>

	</body>
</html>